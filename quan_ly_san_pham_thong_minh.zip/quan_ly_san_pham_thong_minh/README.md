# Quản lý sản phẩm thông minh – bản 1.0

## Chạy thử
1. Giải nén thư mục.
2. Mở `index.html` bằng Chrome, Edge hoặc Firefox.
3. Dữ liệu được lưu trong LocalStorage của trình duyệt.

## Chức năng hiện có
- Dashboard tổng quan.
- Quản lý sản phẩm: thêm, sửa, xóa, tìm kiếm, lọc danh mục.
- Quản lý đơn hàng: tạo đơn, tự động tính tiền và trừ tồn kho.
- Quản lý kho: nhập kho, xuất kho, cảnh báo tồn thấp/hết hàng.
- Báo cáo doanh thu, giá vốn ước tính và giá trị tồn kho.
- Sao lưu/khôi phục JSON, nhập CSV, xuất CSV.
- Giao diện responsive và chế độ tối.

## Lưu ý quan trọng
Đây là bản chạy cục bộ trên một trình duyệt. LocalStorage không phải cơ sở dữ liệu máy chủ và không tự đồng bộ giữa nhiều máy. Không lưu thông tin thẻ ngân hàng hoặc dữ liệu nhạy cảm trong bản này.

Các tính năng cần phát triển thêm để vận hành thực tế:
- Backend + cơ sở dữ liệu (ví dụ Node.js/Express hoặc Python/Flask + SQLite/PostgreSQL).
- Tài khoản, phân quyền nhân viên và nhật ký thao tác.
- Quét QR/mã vạch bằng camera.
- Kết nối VNPay/MoMo qua API/đối tác và xác minh giao dịch ở máy chủ.
- Đồng bộ đa thiết bị, bảo mật và sao lưu máy chủ.
