# NGHĨA STORE – QUẢN LÝ BÁN HÀNG PRO 2.0

## Chạy
Giải nén ZIP và mở index.html bằng Chrome/Edge. Internet cần thiết để tải thư viện mã vạch JsBarcode và tạo QR VietQR.

## Có sẵn
- Quản lý sản phẩm chi tiết: SKU, barcode, danh mục, thương hiệu, biến thể, giá lẻ/sỉ, giá vốn, tồn, định mức, đơn vị, nhà cung cấp, xuất xứ, bảo hành, hạn sử dụng, vị trí kho, mô tả.
- POS tạo đơn nhiều sản phẩm, khách hàng, số điện thoại, giảm giá, phí giao hàng, phương thức/trạng thái thanh toán, ghi chú; tự trừ kho.
- Tra cứu đơn theo mã đơn, mã thanh toán, khách hàng/số điện thoại.
- Xem chi tiết và cập nhật trạng thái; in hóa đơn hoặc lưu PDF qua hộp thoại in.
- Nhập/xuất kho; khách hàng; báo cáo; sao lưu/khôi phục JSON; nhập/xuất CSV.
- Tạo Code 128, in nhiều tem, tra mã vạch/SKU. Máy quét USB kiểu HID có thể nhập như bàn phím vào ô tra cứu.
- Tạo QR chuyển khoản VietQR từ mã ngân hàng, số tài khoản, số tiền và mã thanh toán.

## Giới hạn quan trọng
QR chỉ tạo nội dung chuyển khoản, KHÔNG xác nhận tiền đã vào tài khoản. Trạng thái thanh toán được cập nhật thủ công. Đối soát tự động cần hợp đồng/API ngân hàng hoặc cổng thanh toán, backend và webhook an toàn. Không đưa API secret vào frontend.
Dữ liệu dùng LocalStorage trên trình duyệt hiện tại, không đồng bộ nhiều máy/người dùng. Camera scan, đăng nhập/phân quyền và backend chưa có trong bản này. Hãy sao lưu JSON định kỳ.
